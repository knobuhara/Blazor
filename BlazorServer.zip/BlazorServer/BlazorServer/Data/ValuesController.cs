﻿using BlazorServer.Shared.Entities;
using Microsoft.EntityFrameworkCore;

namespace BlazorServer.Server.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<HealthData> HealthData { get; set; }
    }
}